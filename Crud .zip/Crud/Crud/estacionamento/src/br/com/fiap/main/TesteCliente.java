package br.com.fiap.main;

import java.sql.Connection;
import java.util.ArrayList;
import br.com.fiap.bean.Cliente;
import br.com.fiap.dao.ClienteDAO;
import br.com.fiap.dao.Conexao;

public class TesteCliente {

	public static void main(String[] args) {
	Connection con = Conexao.abrirConexao();
			
			Cliente cb = new Cliente();
			ClienteDAO cd = new ClienteDAO(con);
			

			//inserir
//			cb.setPlaca("JKK1900");
//			cb.setIdCliente(0123);
//			cb.setNomeCliente("Amorgan");
//			System.out.println(cd.inserir(cb));
			
     		//Alterar
			cb.setPlaca("abc1000");
			cb.setIdCliente(3210);
			cb.setNomeCliente("Gustavo");
			System.out.println(cd.alterar(cb));
//			
//			//Excluir
//			cb.setPlaca("JKK1900");
//			System.out.println(cd.excluir(cb));
//			
//			//Listar
//			ArrayList<Cliente> lista = cd.listarTodos();
//			
//			if (lista != null) {
//				for (Cliente cliente : lista) {
//					System.out.println("placa: " + cliente.getPlaca());
//					System.out.println("ID: " + cliente.getIdCliente());
//					System.out.println("Nome do Cliente: " + cliente.getNomeCliente());
//				}
//			}
//			
//			Conexao.fecharConexao(con);
	
	

	}

}
